// Temporary Panel to Provide Demonstration of Themes in Ocean formatted HTML

$(function() {
  $('head').append('<link rel="stylesheet" type="text/css" href="assets/common/panel-style.css">');
  $('body').append("<div id='control_panel_hidden' class='screenonly'>i</div>");

  var color_themes = ['theme_white','theme_sepia','theme_night'];
  var fonts = ['font_gentium','font_sanchez','font_cabin','font_bembo','font_dyslexic'];
  var line_height = ['line-height_1', 'line-height_2', 'line-height_3'];
  var links = '';

  for (i=0; i<color_themes.length; i++) links += ' <a id="'+color_themes[i]+'">'+color_themes[i]+'</a><br> \n ';
  links+= '   --- <br> \n';
  for (i=0; i<fonts.length; i++) links += ' <a id="'+fonts[i]+'">'+fonts[i]+'</a><br> \n ';
  links+= '   --- <br> \n';
  for (i=0; i<line_height.length; i++) links += ' <a id="'+line_height[i]+'">'+line_height[i]+'</a><br> \n ';
  //links+= '   --- <br> \n';
  $('body').append("<div id='control_panel' class='screenonly'></div>");
  $('#control_panel').append(links);


  $("#control_panel a").click(function(){
    var id = $(this).attr('id');
    if (color_themes.indexOf(id)>-1) $('body').removeClass(color_themes.join(' ')).addClass(id);
    else if (fonts.indexOf(id)>-1) $('body').removeClass(fonts.join(' ')).addClass(id);
    else if (line_height.indexOf(id)>-1) $('body').removeClass(line_height.join(' ')).addClass(id);
  });

  $("#control_panel_hidden").mouseenter(function(){
    $(this).hide();
    $("#control_panel").show();
  });

  $("#control_panel").mouseleave(function(){
    $(this).hide();
    $("#control_panel_hidden").show();
  });
});