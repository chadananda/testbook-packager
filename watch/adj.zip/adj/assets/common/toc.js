// Demonstration of extracting a table of contents from
// Ocean formatted HTML

$(function() {
  var toc='', title, id, sectionnum, date, level, toc_level, next_id;

  $(".toc").each(function(i) {
    title = $(this).text().trim() ? $(this).text().trim() : $(this).attr('data-title').trim();
    id = $(this).attr('id').trim();
    next_id = $(this).next('p[id], div.par[id]').attr('id').trim();
    sectionnum = " - <span class='date'>p. " + next_id +'</span> ';
    date = $(this).attr('data-date') ? " - <span class='date'>" + $(this).attr('data-date').trim()+ '</span> ' : ''
    level = ($(this).hasClass('section') || $(this).hasClass('header')) ? 'first' : 'second';
    id = id ? id : next_id;
    if (title && id) toc = toc + "<li class='toc_"+level+"'>"  +
       " <a href='#" + id + "' title='" + title + "'>" + title + "</a> "+ date + sectionnum + "</li>";
  });

  toc_title = '<h2 class="section">'+$("#section_toc").attr('data-title')+'</h2>';
  if (toc.length>1) $("#section_toc").html(toc_title + '<ul>' + toc + '</ul>  <hr class="screenonly">');
   else $('#section_toc').hide();

});