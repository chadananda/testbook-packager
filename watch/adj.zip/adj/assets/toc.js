// Demonstration of extracting a table of contents from
// Ocean formatted HTML

$(function() {
  var toc='', title, id, sectionnum, date, level, toc_level;

  $(".toc[id]").each(function(i) {
    title = $(this).text().trim() ? $(this).text().trim() : $(this).attr('data-title').trim();
    id = $(this).attr('id').trim();
    sectionnum = $(this).attr('data-num') ? "<span class='date'>" + $(this).attr('data-num').trim()+'.</span> ' : '';
    date = $(this).attr('data-date') ? " - <span class='date'>" + $(this).attr('data-date').trim()+ '</span> ' : ''
    level = ($(this).hasClass('section') || $(this).hasClass('header')) ? 'first' : 'second';
    if (title && id) toc = toc + "<li class='toc_"+level+"'>"+ sectionnum  +
       " <a href='#" + id + "' title='" + title + "'>" + title + "</a> "+ date +"</li>";
  });

  toc_title = '<h2 class="section">'+$("#section_toc").attr('data-title')+'</h2>';
  if (toc.length>1) $("#section_toc").html(toc_title + '<ul>' + toc + '</ul>  <hr>');
   else $('#section_toc').hide();

});