// Demonstration of showing hidden footnotes on click
// Ocean formatted HTML

$(function() {
  $("a[data-fnid]").click(function(){
    // when selecting ids with periods, hashes or colons, escaping is required
    var id = '#' + ($(this).attr('data-fnid')).replace( /(:|\.|\[|\])/g, "\\$1" );
    $(id).toggle(400);
  });
});